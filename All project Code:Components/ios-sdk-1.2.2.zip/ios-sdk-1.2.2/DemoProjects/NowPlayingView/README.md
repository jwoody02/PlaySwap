# Now Playing View

A project that demonstrates listening to and displaying the current player state, and allowing the user to control the playback.
