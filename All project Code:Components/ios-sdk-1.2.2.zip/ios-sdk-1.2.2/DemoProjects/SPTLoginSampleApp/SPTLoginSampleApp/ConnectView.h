#import <UIKit/UIKit.h>
#import "ConnectButton.h"

@interface ConnectView : UIView

@property (nonatomic) UILabel *label;

@property (nonatomic) ConnectButton *connectButton;

@end
