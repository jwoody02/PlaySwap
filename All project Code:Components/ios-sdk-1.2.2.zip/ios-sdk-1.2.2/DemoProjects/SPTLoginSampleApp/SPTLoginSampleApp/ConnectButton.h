#import <UIKit/UIKit.h>

@interface ConnectButton : UIButton

+ (UIColor *)customBackgroundColor;

+ (UIColor *)customHighlightedBackgroundColor;

@end
